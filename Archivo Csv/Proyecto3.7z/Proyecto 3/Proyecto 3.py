import csv

with open("stroke.csv") as f:
    reader = csv.reader(f)
    next(reader) #se pasa por encima el header

    
    for patient in reader:
        print(patient[3])
        

   
    
        
        
