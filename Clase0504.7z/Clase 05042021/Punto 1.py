#Algoritmo que muestre los números de 1 al 100

#forma 1
n = 1
while n <= 100:
    print(n)
    n = n + 1


#forma 2
n = 0
while n < 100:
    n = n + 1
    print(n)

#Cada forma tiene una expresión lógica en el while diferente

