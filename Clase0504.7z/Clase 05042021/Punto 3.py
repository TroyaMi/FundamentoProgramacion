#Algoritmo que le pida al usuario varios números hasta que la suma de éstos sea 100 o más.

sum = 0
while sum < 100:
    n = float(input("Digite un valor: "))
    sum = sum + n

