#Algoritmo que muestre los números del 5 al 15

#forma 1
n = 5
while n <= 15:
    print(n)
    n = n + 1


#forma 2
n = 4
while n < 15:
    n = n + 1
    print(n)
    
#Cada forma tiene una expresión lógica en el while diferente

