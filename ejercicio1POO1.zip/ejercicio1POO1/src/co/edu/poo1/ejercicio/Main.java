package co.edu.poo1.ejercicio;

import co.edu.poo1.ejercicio.cafe.Cafe;
import co.edu.poo1.ejercicio.cafe.SacoCafe;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        System.out.println("Buenas, señor usuario. Digite: \n" +
                "1 - Para ver información de un cafe ya definido\n" +
                "2 - Para crear su propio saco de café.");
        int respuesta = entrada.nextInt();
        if (respuesta == 1) {
            verCafe();
        } else {
            crearCafe(entrada);
        }
        entrada.close();
    }
    private static void verCafe (){
        Cafe cafe1 = new Cafe(" deffsx "," frddw3 ",33 );
        verSacoCafe(cafe1);
        cafe1.mostrarInfoCafe();
    }
    private static void verSacoCafe (Cafe cafe){
        SacoCafe sacocafe1 = new SacoCafe(" e3e4rew ", 4.000F , cafe );
        sacocafe1.mostrarInfoSaco();
    }

    private static void crearCafe(Scanner entrada) {
        SacoCafe sacoCafe1 = new SacoCafe();
        SacoCafe sacoCafe2 = new SacoCafe();
        SacoCafe sacoCafe3 = new SacoCafe();
        Cafe cafe1 = new Cafe();

        System.out.println("Señor usuario, cuanto cuesta el saco de cafe?");
        sacoCafe1.setCosto(entrada.nextFloat());
        System.out.println("Cual es ahora la variedad?");
        cafe1.setVariedad(entrada.next());
    }

}
