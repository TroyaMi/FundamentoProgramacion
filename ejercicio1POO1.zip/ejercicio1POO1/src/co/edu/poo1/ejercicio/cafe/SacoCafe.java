package co.edu.poo1.ejercicio.cafe;

public class SacoCafe {

    private String codigoBarras;
    private float costo;
    private Cafe cafeAsignado;

    public SacoCafe(String codigoBarras, float costo, Cafe cafeAsignado){
        this.codigoBarras = codigoBarras;
        this.costo = costo;
        this.cafeAsignado = cafeAsignado;
    }

    public SacoCafe() {

    }

    public void almacenar(){
    }

    public SacoCafe(String codigoBarras, int i, String cafe){
    }

    public String getCodigoBarras() {
        return codigoBarras;
    }

    public void setCodigoBarras(String codigoBarras) {
        this.codigoBarras = codigoBarras;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(Float costo) {
        this.costo = costo;
    }

    public Cafe getCafeAsignado() {
        return cafeAsignado;
    }

    public void setCafeAsignado(Cafe cafeAsignado) {
        this.cafeAsignado = cafeAsignado;
    }

    public void mostrarInfoSaco (){
        System.out.println("serial " + this.codigoBarras);
        System.out.println("costo " + this.costo);
        System.out.println("cafe asignado " + this.cafeAsignado.getAlturaCultivo());
    }
}
