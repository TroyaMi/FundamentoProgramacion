package co.edu.poo1.ejercicio.cafe;

public class Cafe {

    private String serial;
    private String variedad;
    private Integer alturaCultivo;

    public void vencimiento(){
    }

    public Cafe (){
    }

    public Cafe (String serial,String variedad,Integer alturaCultivo){
        this.serial = serial;
        this.variedad = variedad;
        this.alturaCultivo = alturaCultivo;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getVariedad() {
        return variedad;
    }

    public void setVariedad(String variedad) {
        this.variedad = variedad;
    }

    public Integer getAlturaCultivo() {
        return alturaCultivo;
    }

    public void setAlturaCultivo(Integer alturaCultivo) {
        this.alturaCultivo = alturaCultivo;


    }
    public void mostrarInfoCafe (){
        System.out.println("serial" + this.serial);
        System.out.println("variedad" + this.variedad);
        System.out.println("altura cultivo" + this.alturaCultivo);}

}
